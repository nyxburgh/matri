<?php
// app/core/Autoloader.php

spl_autoload_register(function (string $class): void {
    $dirs = [
        BASE_PATH . '/app/core/',
        BASE_PATH . '/app/modules/Admin/Controllers/',
        BASE_PATH . '/app/modules/Admin/Models/',
        BASE_PATH . '/app/modules/User/Controllers/',
        BASE_PATH . '/app/modules/User/Models/',
        BASE_PATH . '/app/modules/Profile/Controllers/',
        BASE_PATH . '/app/modules/Profile/Models/',
    ];
    foreach ($dirs as $dir) {
        $file = $dir . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

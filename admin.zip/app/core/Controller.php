<?php
// app/core/Controller.php

abstract class Controller {

    protected function view(string $viewPath, array $data = [], string $layout = ''): void {
        extract($data);
        $csrf = Session::generateCsrf();

        if ($layout) {
            $layoutFile = BASE_PATH . '/app/modules/' . $layout;
            if (file_exists($layoutFile)) {
                $content = $this->renderPartial($viewPath, $data);
                include $layoutFile;
                return;
            }
        }
        include BASE_PATH . '/app/modules/' . $viewPath;
    }

    private function renderPartial(string $viewPath, array $data): string {
        extract($data);
        ob_start();
        include BASE_PATH . '/app/modules/' . $viewPath;
        return ob_get_clean();
    }

    protected function redirect(string $url): void {
        header('Location: ' . APP_URL . '/' . ltrim($url, '/'));
        exit;
    }

    protected function json(mixed $data, int $code = 200): void {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

    protected function requireAdmin(): void {
        if (!Session::has('admin_id') || Session::get('admin_role') !== 'admin') {
            Session::flash('error', 'Please login to continue.');
            $this->redirect('admin/login');
        }
    }

    protected function verifyCsrf(): void {
        $token = $_POST['_csrf'] ?? '';
        if (!Session::verifyCsrf($token)) {
            http_response_code(403);
            die('CSRF token mismatch. Please go back and try again.');
        }
    }

    protected function sanitize(string $input): string {
        return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
    }

    protected function input(string $key, string $default = ''): string {
        return $this->sanitize($_POST[$key] ?? $_GET[$key] ?? $default);
    }

    protected function paginationData(int $total, int $perPage, int $currentPage): array {
        return [
            'total'        => $total,
            'per_page'     => $perPage,
            'current_page' => $currentPage,
            'last_page'    => (int) ceil($total / $perPage),
        ];
    }
}

<?php
// public/index.php — Front Controller

define('BASE_PATH', dirname(__DIR__));

require_once BASE_PATH . '/config/config.php';
require_once BASE_PATH . '/app/core/Autoloader.php';
require_once BASE_PATH . '/app/core/Logger.php';
require_once BASE_PATH . '/app/core/Database.php';
require_once BASE_PATH . '/app/core/Session.php';
require_once BASE_PATH . '/app/core/Router.php';
require_once BASE_PATH . '/app/core/Controller.php';

Session::start();

$router = new Router();

// Load module routes
require_once BASE_PATH . '/app/modules/Admin/Routes/admin.routes.php';

// Dispatch
$uri           = $_GET['url'] ?? '/';
$requestMethod = $_SERVER['REQUEST_METHOD'];
$router->dispatch('/' . trim($uri, '/'), $requestMethod);
